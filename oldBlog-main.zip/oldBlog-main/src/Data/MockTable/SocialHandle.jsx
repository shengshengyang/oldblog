export const SocialHandleData = [
    {
        logo: 'fa-facebook',
        title: 'Facebook',
        count1: 'Post',
        end1: 6589,
        count2: 'Like',
        end2: 75269
    },
    {
        logo: 'fa-twitter',
        title: 'Twitter',
        count1: 'Post',
        end1: 6589,
        count2: 'Follower',
        end2: 75269
    },
    {
        logo: 'fa-linkedin',
        title: 'Linkdin',
        count1: 'Post',
        end1: 1234,
        count2: 'Linkdin',
        end2: 4369
    },
    {
        logo: 'fa-google-plus',
        title: 'GooglePlus',
        count1: 'Post',
        end1: 369,
        count2: 'Follower',
        end2: 3458
    },

]
export const NewsUpdateData=[
    {
        line:true,
        headingClass:'activity-dot-secondary',
        heading:'Update Product',
        desc:'Quisque a consequat ante Sit amet magna at volutapt.'
    },
    {        
        headingClass:'activity-dot-primary',
        heading:'James liked Nike Shoes',
        desc:'Aenean sit amet magna vel magna fringilla ferme.'
    },
    {
        
        headingClass:'activity-dot-secondary',
        heading:'john just buy your product',
        highlight:<i className="fa fa-circle circle-dot-secondary pull-right"></i>,
        desc:'Vestibulum nec mi suscipit, dapibus purus.....'
    },
    {
        
        headingClass:'activity-dot-primary',
        heading:'Jihan Doe just save your product',
        highlight:<i className="fa fa-circle circle-dot-primary pull-right"></i>,
        desc:'Quisque a consequat ante Sit amet magna at volutapt.'
    },

];
import React from 'react';

const Spinner = (props) =>(
  <div {...props.attrSpinner}  />
);

export default Spinner;
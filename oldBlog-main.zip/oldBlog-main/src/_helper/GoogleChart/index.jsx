import { createContext } from 'react';

const GoogleContext = createContext();

export default GoogleContext;

import { createContext } from 'react';

const TableContext = createContext();

export default TableContext;

import { createContext } from 'react';

const TaskContext = createContext();

export default TaskContext;

import { createContext } from 'react';

const FaqContext = createContext();

export default FaqContext;
